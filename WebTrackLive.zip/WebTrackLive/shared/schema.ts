import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const websites = pgTable("websites", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  url: text("url").notNull().unique(),
  status: text("status", { enum: ["online", "offline", "warning"] }).notNull().default("online"),
  responseTime: integer("response_time"), // in milliseconds
  uptime: text("uptime").notNull().default("100%"),
  lastChecked: timestamp("last_checked").defaultNow(),
  isActive: boolean("is_active").notNull().default(true),
  // Core Web Vitals metrics
  lcp: integer("lcp"), // Largest Contentful Paint in milliseconds
  fid: integer("fid"), // First Input Delay in milliseconds  
  cls: text("cls"), // Cumulative Layout Shift (decimal as string)
  fcp: integer("fcp"), // First Contentful Paint in milliseconds
  tti: integer("tti"), // Time to Interactive in milliseconds
  tbt: integer("tbt"), // Total Blocking Time in milliseconds
});

export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  websiteId: varchar("website_id").references(() => websites.id),
  title: text("title").notNull(),
  message: text("message"),
  type: text("type", { enum: ["error", "warning", "info"] }).notNull(),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertWebsiteSchema = createInsertSchema(websites).omit({
  id: true,
  lastChecked: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

export type InsertWebsite = z.infer<typeof insertWebsiteSchema>;
export type Website = typeof websites.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alerts.$inferSelect;

// Dashboard stats type
export type DashboardStats = {
  totalSites: number;
  onlineSites: number;
  offlineSites: number;
  warningSites: number;
  avgResponseTime: number;
  overallUptime: string;
  // Core Web Vitals averages
  avgLCP: number;
  avgFID: number;
  avgCLS: number;
  avgFCP: number;
  avgTTI: number;
  avgTBT: number;
  performanceScore: number; // Overall performance score (0-100)
};
