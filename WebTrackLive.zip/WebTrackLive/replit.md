# WebTracker - Website Monitoring Dashboard

## Overview

WebTracker is a modern website monitoring application built with React, Express, and PostgreSQL. It provides real-time monitoring of websites with uptime tracking, response time analysis, and alert management. The application features a clean dashboard interface for managing monitored websites, viewing analytics, and handling alerts with automatic refresh capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern component patterns
- **Routing**: Wouter for lightweight client-side routing with support for dashboard sections (websites, alerts, analytics, settings)
- **UI Framework**: Shadcn/UI components built on Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with custom design system including CSS variables for theming and glass morphism effects
- **State Management**: TanStack Query (React Query) for server state management with automatic caching and real-time updates
- **Forms**: React Hook Form with Zod validation for type-safe form handling
- **Theme System**: Custom theme provider with light/dark mode toggle and localStorage persistence

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Language**: TypeScript for full-stack type safety with ES modules
- **Database Layer**: Drizzle ORM with PostgreSQL for type-safe database operations and schema management
- **Data Storage**: In-memory storage implementation with interface for easy database migration
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **Development Setup**: Vite integration for hot module replacement and development server

### API Design
- **REST Endpoints**: Standard CRUD operations for websites and alerts
- **Dashboard Stats**: Aggregated metrics endpoint for real-time dashboard updates
- **Error Handling**: Centralized error middleware with consistent JSON responses
- **Request Logging**: Custom middleware for API request tracking and performance monitoring

### Database Schema
- **Websites Table**: Core entity with URL, status, response time, uptime percentage, and monitoring metadata
- **Alerts Table**: Notification system with website references, alert types (error/warning/info), and read status
- **Migration System**: Drizzle Kit for schema versioning and database migrations
- **UUID Primary Keys**: Using PostgreSQL's gen_random_uuid() for distributed-friendly identifiers

### Build and Deployment
- **Frontend Build**: Vite bundler with optimized production builds and code splitting
- **Backend Build**: ESBuild for server-side bundling with external package handling
- **Development Mode**: Integrated Vite dev server with Express for full-stack development
- **Production Mode**: Static file serving with optimized asset delivery

## External Dependencies

### Database
- **Neon Database**: Serverless PostgreSQL with connection pooling via @neondatabase/serverless
- **Connection Management**: Environment-based DATABASE_URL configuration with connection validation

### UI Component Libraries
- **Radix UI**: Comprehensive set of accessible, unstyled components for complex UI patterns
- **Lucide React**: Modern icon library with consistent styling and tree-shaking support
- **Date-fns**: Lightweight date manipulation library for timestamp formatting
- **Embla Carousel**: Touch-friendly carousel component for responsive layouts

### Development Tools
- **Replit Integration**: Development environment setup with error overlays and debugging tools
- **TypeScript**: Strict type checking with path mapping for clean imports
- **PostCSS**: CSS processing with Tailwind CSS and Autoprefixer for cross-browser compatibility

### Monitoring and Analytics
- **Real-time Updates**: Automatic dashboard refresh every 5 seconds for live monitoring
- **Response Time Tracking**: Performance metrics collection and trend analysis
- **Uptime Calculation**: Availability percentage tracking with historical data
- **Alert System**: Automated notification generation based on website status changes