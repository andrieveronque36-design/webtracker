import { useState } from "react";
import { Sidebar } from "@/components/dashboard/sidebar";
import { WebsiteGrid } from "@/components/dashboard/website-grid";
import { AddWebsiteModal } from "@/components/dashboard/add-website-modal";
import { Globe, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function WebsitesPage() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <Sidebar />
      <main className="flex-1 overflow-hidden">
        <div className="glass-effect border-b border-slate-200 dark:border-slate-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-200 flex items-center space-x-2">
                <Globe className="w-6 h-6" />
                <span>Website Management</span>
              </h1>
              <p className="text-slate-600 dark:text-slate-400">
                Manage and monitor all your websites in one place
              </p>
            </div>
            <Button
              onClick={() => setIsAddModalOpen(true)}
              className="bg-blue-500 hover:bg-blue-600"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Website
            </Button>
          </div>
        </div>
        
        <div className="p-6 h-full overflow-y-auto">
          <WebsiteGrid />
        </div>
      </main>
      
      <AddWebsiteModal
        open={isAddModalOpen}
        onOpenChange={setIsAddModalOpen}
      />
    </div>
  );
}