import { useState } from "react";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useTheme } from "@/components/theme-provider";
import { 
  Settings, 
  Bell, 
  Mail, 
  MessageSquare, 
  Shield, 
  Clock, 
  Globe, 
  User, 
  Database,
  Download,
  Upload,
  Trash2,
  Save,
  RefreshCw,
  Eye,
  EyeOff
} from "lucide-react";

export default function SettingsPage() {
  const { theme, toggleTheme } = useTheme();
  const [notifications, setNotifications] = useState({
    email: true,
    sms: false,
    push: true,
    desktop: true,
  });
  
  const [monitoring, setMonitoring] = useState({
    interval: "300", // 5 minutes
    timeout: "30", // 30 seconds
    retries: "3",
    followRedirects: true,
    checkSSL: true,
  });

  const [profile, setProfile] = useState({
    name: "John Doe",
    email: "john@example.com",
    timezone: "UTC",
    language: "en",
  });

  const [showApiKey, setShowApiKey] = useState(false);

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <Sidebar />
      <main className="flex-1 overflow-hidden">
        <div className="glass-effect border-b border-slate-200 dark:border-slate-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-200 flex items-center space-x-2">
                <Settings className="w-6 h-6" />
                <span>Settings</span>
              </h1>
              <p className="text-slate-600 dark:text-slate-400">
                Configure your monitoring preferences and account settings
              </p>
            </div>
          </div>
        </div>

        <div className="p-6 h-full overflow-y-auto">
          <Tabs defaultValue="general" className="space-y-6">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="general">General</TabsTrigger>
              <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
              <TabsTrigger value="api">API</TabsTrigger>
              <TabsTrigger value="data">Data</TabsTrigger>
            </TabsList>

            {/* General Settings */}
            <TabsContent value="general" className="space-y-6">
              <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60">
                <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4 flex items-center space-x-2">
                  <User className="w-5 h-5" />
                  <span>Profile Settings</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={profile.name}
                      onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      value={profile.email}
                      onChange={(e) => setProfile(prev => ({ ...prev, email: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="timezone">Timezone</Label>
                    <Select value={profile.timezone} onValueChange={(value) => setProfile(prev => ({ ...prev, timezone: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="UTC">UTC</SelectItem>
                        <SelectItem value="America/New_York">Eastern Time</SelectItem>
                        <SelectItem value="America/Chicago">Central Time</SelectItem>
                        <SelectItem value="America/Denver">Mountain Time</SelectItem>
                        <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                        <SelectItem value="Europe/London">London</SelectItem>
                        <SelectItem value="Europe/Paris">Paris</SelectItem>
                        <SelectItem value="Asia/Tokyo">Tokyo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="language">Language</Label>
                    <Select value={profile.language} onValueChange={(value) => setProfile(prev => ({ ...prev, language: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="es">Spanish</SelectItem>
                        <SelectItem value="fr">French</SelectItem>
                        <SelectItem value="de">German</SelectItem>
                        <SelectItem value="ja">Japanese</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </Card>

              <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60">
                <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4">
                  Appearance
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Dark Mode</Label>
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Toggle between light and dark themes
                      </p>
                    </div>
                    <Switch
                      checked={theme === "dark"}
                      onCheckedChange={toggleTheme}
                    />
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Monitoring Settings */}
            <TabsContent value="monitoring" className="space-y-6">
              <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60">
                <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4 flex items-center space-x-2">
                  <Globe className="w-5 h-5" />
                  <span>Monitoring Configuration</span>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="interval">Check Interval</Label>
                    <Select value={monitoring.interval} onValueChange={(value) => setMonitoring(prev => ({ ...prev, interval: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="60">1 minute</SelectItem>
                        <SelectItem value="300">5 minutes</SelectItem>
                        <SelectItem value="600">10 minutes</SelectItem>
                        <SelectItem value="1800">30 minutes</SelectItem>
                        <SelectItem value="3600">1 hour</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      How often to check your websites
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="timeout">Request Timeout</Label>
                    <Select value={monitoring.timeout} onValueChange={(value) => setMonitoring(prev => ({ ...prev, timeout: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="10">10 seconds</SelectItem>
                        <SelectItem value="30">30 seconds</SelectItem>
                        <SelectItem value="60">60 seconds</SelectItem>
                        <SelectItem value="120">2 minutes</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Maximum time to wait for response
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="retries">Retry Attempts</Label>
                    <Select value={monitoring.retries} onValueChange={(value) => setMonitoring(prev => ({ ...prev, retries: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 retry</SelectItem>
                        <SelectItem value="2">2 retries</SelectItem>
                        <SelectItem value="3">3 retries</SelectItem>
                        <SelectItem value="5">5 retries</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Number of retries before marking as down
                    </p>
                  </div>
                </div>
                
                <Separator className="my-6" />
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Follow Redirects</Label>
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Automatically follow HTTP redirects
                      </p>
                    </div>
                    <Switch
                      checked={monitoring.followRedirects}
                      onCheckedChange={(checked) => setMonitoring(prev => ({ ...prev, followRedirects: checked }))}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>SSL Certificate Check</Label>
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Verify SSL certificates and warn on expiry
                      </p>
                    </div>
                    <Switch
                      checked={monitoring.checkSSL}
                      onCheckedChange={(checked) => setMonitoring(prev => ({ ...prev, checkSSL: checked }))}
                    />
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Notifications */}
            <TabsContent value="notifications" className="space-y-6">
              <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60">
                <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4 flex items-center space-x-2">
                  <Bell className="w-5 h-5" />
                  <span>Notification Channels</span>
                </h3>
                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 border border-slate-200 dark:border-slate-700 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Mail className="w-5 h-5 text-blue-500" />
                      <div>
                        <Label>Email Notifications</Label>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          Receive alerts via email
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={notifications.email}
                        onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, email: checked }))}
                      />
                      {notifications.email && <Badge variant="default">Active</Badge>}
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 border border-slate-200 dark:border-slate-700 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <MessageSquare className="w-5 h-5 text-green-500" />
                      <div>
                        <Label>SMS Notifications</Label>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          Receive alerts via text message
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={notifications.sms}
                        onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, sms: checked }))}
                      />
                      {!notifications.sms && <Badge variant="secondary">Setup Required</Badge>}
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 border border-slate-200 dark:border-slate-700 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Bell className="w-5 h-5 text-purple-500" />
                      <div>
                        <Label>Push Notifications</Label>
                        <p className="text-sm text-slate-500 dark:text-slate-400">
                          Browser push notifications
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={notifications.push}
                        onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, push: checked }))}
                      />
                      {notifications.push && <Badge variant="default">Active</Badge>}
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Security */}
            <TabsContent value="security" className="space-y-6">
              <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60">
                <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4 flex items-center space-x-2">
                  <Shield className="w-5 h-5" />
                  <span>Security Settings</span>
                </h3>
                <div className="space-y-6">
                  <div>
                    <Label htmlFor="current-password">Current Password</Label>
                    <Input
                      id="current-password"
                      type="password"
                      placeholder="Enter current password"
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="new-password">New Password</Label>
                    <Input
                      id="new-password"
                      type="password"
                      placeholder="Enter new password"
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="confirm-password">Confirm New Password</Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      placeholder="Confirm new password"
                      className="mt-2"
                    />
                  </div>
                  <Button className="bg-blue-500 hover:bg-blue-600">
                    Update Password
                  </Button>
                </div>
              </Card>
            </TabsContent>

            {/* API */}
            <TabsContent value="api" className="space-y-6">
              <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60">
                <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4 flex items-center space-x-2">
                  <Database className="w-5 h-5" />
                  <span>API Access</span>
                </h3>
                <div className="space-y-6">
                  <div>
                    <Label htmlFor="api-key">API Key</Label>
                    <div className="flex items-center space-x-2 mt-2">
                      <Input
                        id="api-key"
                        type={showApiKey ? "text" : "password"}
                        value="wt_1234567890abcdef"
                        readOnly
                        className="flex-1"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowApiKey(!showApiKey)}
                      >
                        {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                      <Button variant="outline" size="sm">
                        <RefreshCw className="w-4 h-4" />
                      </Button>
                    </div>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
                      Use this key to access the WebTracker API
                    </p>
                  </div>

                  <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <h4 className="font-medium text-slate-800 dark:text-slate-200 mb-2">
                      API Endpoints
                    </h4>
                    <div className="space-y-2 text-sm text-slate-600 dark:text-slate-400 font-mono">
                      <p>GET /api/websites</p>
                      <p>POST /api/websites</p>
                      <p>GET /api/alerts</p>
                      <p>GET /api/dashboard/stats</p>
                    </div>
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Data Management */}
            <TabsContent value="data" className="space-y-6">
              <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60">
                <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4">
                  Data Management
                </h3>
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Export Data</Label>
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Download all your monitoring data
                      </p>
                    </div>
                    <Button variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Import Data</Label>
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Import websites from a file
                      </p>
                    </div>
                    <Button variant="outline">
                      <Upload className="w-4 h-4 mr-2" />
                      Import
                    </Button>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-red-600 dark:text-red-400">Delete All Data</Label>
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Permanently delete all monitoring data
                      </p>
                    </div>
                    <Button variant="destructive">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Save Button */}
          <div className="flex justify-end pt-6">
            <Button className="bg-blue-500 hover:bg-blue-600">
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}