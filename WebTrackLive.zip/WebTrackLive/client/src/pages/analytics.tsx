import { Sidebar } from "@/components/dashboard/sidebar";
import { AnalyticsCharts } from "@/components/dashboard/analytics-charts";
import { BarChart3 } from "lucide-react";

export default function AnalyticsPage() {
  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <Sidebar />
      <main className="flex-1 overflow-hidden">
        <div className="glass-effect border-b border-slate-200 dark:border-slate-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-200 flex items-center space-x-2">
                <BarChart3 className="w-6 h-6" />
                <span>Advanced Analytics</span>
              </h1>
              <p className="text-slate-600 dark:text-slate-400">
                Detailed performance insights and monitoring trends
              </p>
            </div>
          </div>
        </div>
        
        <div className="p-6 h-full overflow-y-auto">
          <AnalyticsCharts showDetailedView={true} />
        </div>
      </main>
    </div>
  );
}