import { useState, useEffect } from "react";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { StatusCards } from "@/components/dashboard/status-cards";
import { WebsiteGrid } from "@/components/dashboard/website-grid";
import { AnalyticsCharts } from "@/components/dashboard/analytics-charts";
import { AddWebsiteModal } from "@/components/dashboard/add-website-modal";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const queryClient = useQueryClient();

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/websites"] });
    queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
  };

  // Simulate real-time updates every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      handleRefresh();
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <Sidebar />
      <main className="flex-1 overflow-hidden">
        <div className="flex justify-end p-4">
          <Link href="/login">
            <Button className="bg-blue-500 hover:bg-blue-600 text-white">
              Go to Login
            </Button>
          </Link>
        </div>
        <Header
          onAddWebsite={() => setIsAddModalOpen(true)}
          onRefresh={handleRefresh}
        />
        <div className="p-6 h-full overflow-y-auto">
          <StatusCards onAddWebsite={() => setIsAddModalOpen(true)} />
          <WebsiteGrid />
          <AnalyticsCharts />
        </div>
      </main>
      <AddWebsiteModal
        open={isAddModalOpen}
        onOpenChange={setIsAddModalOpen}
      />
    </div>
  );
}
