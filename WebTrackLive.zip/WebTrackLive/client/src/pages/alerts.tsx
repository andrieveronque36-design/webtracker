import { useState } from "react";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Bell, 
  Search, 
  Filter, 
  MoreVertical, 
  Check, 
  Trash2, 
  AlertTriangle, 
  Info, 
  X,
  Clock,
  Settings,
  Mail,
  MessageSquare
} from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger, DropdownMenuItem } from "@/components/ui/dropdown-menu";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Alert, Website } from "@shared/schema";

export default function AlertsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [selectedAlerts, setSelectedAlerts] = useState<string[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: alerts = [] } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
  });

  const { data: websites = [] } = useQuery<Website[]>({
    queryKey: ["/api/websites"],
  });

  const markReadMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("PATCH", `/api/alerts/${id}/read`);
      return response.ok;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/alerts/unread"] });
    },
  });

  const filteredAlerts = alerts.filter((alert) => {
    const searchMatch = searchQuery === "" || 
      alert.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (alert.message && alert.message.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const typeMatch = filterType === "all" || alert.type === filterType;
    const statusMatch = filterStatus === "all" || 
      (filterStatus === "unread" && !alert.isRead) ||
      (filterStatus === "read" && alert.isRead);
    
    return searchMatch && typeMatch && statusMatch;
  });

  const handleSelectAlert = (alertId: string, checked: boolean) => {
    if (checked) {
      setSelectedAlerts(prev => [...prev, alertId]);
    } else {
      setSelectedAlerts(prev => prev.filter(id => id !== alertId));
    }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedAlerts(filteredAlerts.map(a => a.id));
    } else {
      setSelectedAlerts([]);
    }
  };

  const handleBulkMarkRead = async () => {
    for (const id of selectedAlerts) {
      await markReadMutation.mutateAsync(id);
    }
    setSelectedAlerts([]);
    toast({
      title: "Success",
      description: `${selectedAlerts.length} alerts marked as read`,
    });
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "error":
        return <X className="w-4 h-4 text-red-500" />;
      case "warning":
        return <AlertTriangle className="w-4 h-4 text-amber-500" />;
      case "info":
        return <Info className="w-4 h-4 text-blue-500" />;
      default:
        return <Bell className="w-4 h-4 text-slate-500" />;
    }
  };

  const getAlertBadgeVariant = (type: string) => {
    switch (type) {
      case "error":
        return "destructive";
      case "warning":
        return "secondary";
      case "info":
        return "default";
      default:
        return "outline";
    }
  };

  const getWebsiteName = (websiteId: string | null) => {
    if (!websiteId) return "Unknown";
    const website = websites.find(w => w.id === websiteId);
    return website ? website.name : "Unknown";
  };

  const unreadCount = alerts.filter(a => !a.isRead).length;

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <Sidebar />
      <main className="flex-1 overflow-hidden">
        <div className="glass-effect border-b border-slate-200 dark:border-slate-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-200 flex items-center space-x-2">
                <Bell className="w-6 h-6" />
                <span>Alert Management</span>
                {unreadCount > 0 && (
                  <Badge variant="destructive" className="ml-2">
                    {unreadCount} unread
                  </Badge>
                )}
              </h1>
              <p className="text-slate-600 dark:text-slate-400">
                Monitor and manage all your website alerts
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Notification Settings
              </Button>
            </div>
          </div>
        </div>

        <div className="p-6 h-full overflow-y-auto">
          {/* Alert Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card className="glass-effect p-4 border border-slate-200/60 dark:border-slate-700/60">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center">
                  <X className="w-5 h-5 text-red-500" />
                </div>
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Critical</p>
                  <p className="text-lg font-bold text-red-500">
                    {alerts.filter(a => a.type === 'error').length}
                  </p>
                </div>
              </div>
            </Card>
            
            <Card className="glass-effect p-4 border border-slate-200/60 dark:border-slate-700/60">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Warnings</p>
                  <p className="text-lg font-bold text-amber-500">
                    {alerts.filter(a => a.type === 'warning').length}
                  </p>
                </div>
              </div>
            </Card>
            
            <Card className="glass-effect p-4 border border-slate-200/60 dark:border-slate-700/60">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
                  <Info className="w-5 h-5 text-blue-500" />
                </div>
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Info</p>
                  <p className="text-lg font-bold text-blue-500">
                    {alerts.filter(a => a.type === 'info').length}
                  </p>
                </div>
              </div>
            </Card>
            
            <Card className="glass-effect p-4 border border-slate-200/60 dark:border-slate-700/60">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center">
                  <Bell className="w-5 h-5 text-slate-500" />
                </div>
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">Unread</p>
                  <p className="text-lg font-bold text-slate-800 dark:text-slate-200">
                    {unreadCount}
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* Filters and Search */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6 gap-4">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              {/* Search */}
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
                <Input
                  placeholder="Search alerts..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-full sm:w-64"
                />
              </div>
              
              {/* Type Filter */}
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full sm:w-32">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                </SelectContent>
              </Select>
              
              {/* Status Filter */}
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full sm:w-32">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="unread">Unread</SelectItem>
                  <SelectItem value="read">Read</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Bulk Actions */}
            {selectedAlerts.length > 0 && (
              <Button
                onClick={handleBulkMarkRead}
                className="bg-blue-500 hover:bg-blue-600"
              >
                <Check className="w-4 h-4 mr-2" />
                Mark Read ({selectedAlerts.length})
              </Button>
            )}
          </div>

          {/* Bulk Selection Header */}
          {alerts.length > 0 && (
            <div className="mb-4 flex items-center space-x-4 p-3 bg-slate-50/50 dark:bg-slate-800/30 rounded-lg border border-slate-200/60 dark:border-slate-700/60">
              <Checkbox
                checked={selectedAlerts.length === filteredAlerts.length && filteredAlerts.length > 0}
                onCheckedChange={handleSelectAll}
              />
              <span className="text-sm text-slate-600 dark:text-slate-400">
                {selectedAlerts.length === filteredAlerts.length && filteredAlerts.length > 0
                  ? `All ${filteredAlerts.length} alerts selected`
                  : `Select all ${filteredAlerts.length} alerts`}
              </span>
              {selectedAlerts.length > 0 && (
                <Badge variant="secondary" className="ml-auto">
                  {selectedAlerts.length} selected
                </Badge>
              )}
            </div>
          )}

          {/* Alerts List */}
          <div className="space-y-3">
            {filteredAlerts.length > 0 ? (
              filteredAlerts.map((alert) => (
                <Card 
                  key={alert.id} 
                  className={`glass-effect p-4 border transition-all duration-300 ${
                    selectedAlerts.includes(alert.id)
                      ? "border-blue-300 dark:border-blue-600 bg-blue-50/30 dark:bg-blue-900/10"
                      : alert.isRead 
                      ? "border-slate-200/60 dark:border-slate-700/60" 
                      : "border-amber-300 dark:border-amber-600 bg-amber-50/20 dark:bg-amber-900/10"
                  }`}
                >
                  <div className="flex items-start space-x-4">
                    <Checkbox
                      checked={selectedAlerts.includes(alert.id)}
                      onCheckedChange={(checked) => handleSelectAlert(alert.id, !!checked)}
                    />
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-2 mb-2">
                          {getAlertIcon(alert.type)}
                          <Badge variant={getAlertBadgeVariant(alert.type)} className="text-xs">
                            {alert.type.toUpperCase()}
                          </Badge>
                          {!alert.isRead && (
                            <Badge variant="outline" className="text-xs">
                              NEW
                            </Badge>
                          )}
                        </div>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="p-1">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {!alert.isRead && (
                              <DropdownMenuItem onClick={() => markReadMutation.mutate(alert.id)}>
                                <Check className="w-4 h-4 mr-2" />
                                Mark as Read
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem className="text-slate-600 dark:text-slate-400">
                              <Mail className="w-4 h-4 mr-2" />
                              Send Email
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600 dark:text-red-400">
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                      
                      <h3 className={`text-lg font-semibold mb-1 ${
                        alert.isRead ? 'text-slate-600 dark:text-slate-400' : 'text-slate-800 dark:text-slate-200'
                      }`}>
                        {alert.title}
                      </h3>
                      
                      {alert.message && (
                        <p className={`text-sm mb-3 ${
                          alert.isRead ? 'text-slate-500 dark:text-slate-500' : 'text-slate-600 dark:text-slate-400'
                        }`}>
                          {alert.message}
                        </p>
                      )}
                      
                      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-500">
                        <div className="flex items-center space-x-4">
                          <span>Website: {getWebsiteName(alert.websiteId)}</span>
                          <span className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>{alert.createdAt ? new Date(alert.createdAt).toLocaleString() : 'Unknown'}</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))
            ) : (
              <div className="text-center py-16">
                <Bell className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-slate-600 dark:text-slate-400 mb-2">
                  {alerts.length === 0 ? "No alerts yet" : "No matching alerts"}
                </h3>
                <p className="text-slate-500 dark:text-slate-500">
                  {alerts.length === 0 
                    ? "When your websites have issues, alerts will appear here" 
                    : "Try adjusting your filters to see more alerts"
                  }
                </p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}