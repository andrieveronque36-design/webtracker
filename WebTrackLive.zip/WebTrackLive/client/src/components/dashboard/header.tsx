import { Plus, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import type { DashboardStats } from "@shared/schema";

interface HeaderProps {
  onAddWebsite: () => void;
  onRefresh: () => void;
}

export function Header({ onAddWebsite, onRefresh }: HeaderProps) {
  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  return (
    <header className="glass-effect border-b border-slate-200 dark:border-slate-700 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-200">
            Dashboard Overview
          </h1>
          <p className="text-slate-600 dark:text-slate-400">
            Real-time monitoring for all your websites
          </p>
        </div>
        <div className="flex items-center space-x-4">
          {/* Quick Stats */}
          <div className="flex items-center space-x-6">
            <div className="text-center">
              <div className="text-lg font-bold text-emerald-500">
                {stats?.totalSites || 0}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Total Sites</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-emerald-500">
                {stats?.onlineSites || 0}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Online</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-red-500">
                {stats?.offlineSites || 0}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Offline</div>
            </div>
          </div>

          {/* Action Buttons */}
          <Button
            onClick={onAddWebsite}
            className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors duration-200 flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add Website</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onRefresh}
            className="p-2 text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors duration-200"
          >
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}
