import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Download, 
  Check, 
  AlertTriangle, 
  X, 
  Search, 
  MoreVertical, 
  Trash2, 
  Edit, 
  Plus, 
  Globe,
  ExternalLink,
  Activity
} from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger, DropdownMenuItem } from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import type { Website } from "@shared/schema";

export function WebsiteGrid() {
  const [filter, setFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedSites, setSelectedSites] = useState<string[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: websites = [] } = useQuery<Website[]>({
    queryKey: ["/api/websites"],
  });

  const deleteWebsiteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/websites/${id}`);
      return response.ok;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/websites"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Website removed successfully",
      });
      setSelectedSites(prev => prev.filter(id => !prev.includes(id)));
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove website",
        variant: "destructive",
      });
    },
  });

  const filteredWebsites = websites.filter((website) => {
    // Filter by status
    const statusMatch = filter === "all" || website.status === filter;
    
    // Filter by search query
    const searchMatch = searchQuery === "" || 
      website.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      website.url.toLowerCase().includes(searchQuery.toLowerCase());
    
    return statusMatch && searchMatch;
  });

  const handleSelectSite = (siteId: string, checked: boolean) => {
    if (checked) {
      setSelectedSites(prev => [...prev, siteId]);
    } else {
      setSelectedSites(prev => prev.filter(id => id !== siteId));
    }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedSites(filteredWebsites.map(w => w.id));
    } else {
      setSelectedSites([]);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedSites.length === 0) return;
    
    for (const id of selectedSites) {
      await deleteWebsiteMutation.mutateAsync(id);
    }
    setSelectedSites([]);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "online":
        return <Check className="text-emerald-500 w-4 h-4" />;
      case "warning":
        return <AlertTriangle className="text-amber-500 w-4 h-4" />;
      case "offline":
        return <X className="text-red-500 w-4 h-4" />;
      default:
        return <Check className="text-emerald-500 w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "emerald";
      case "warning":
        return "amber";
      case "offline":
        return "red";
      default:
        return "emerald";
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "online":
        return "default";
      case "warning":
        return "secondary";
      case "offline":
        return "destructive";
      default:
        return "default";
    }
  };

  const handleExport = () => {
    const dataStr = JSON.stringify(websites, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `websites-data-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleOpenWebsite = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="mb-8">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6 gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200">
            Website Monitoring
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {filteredWebsites.length} of {websites.length} websites
            {selectedSites.length > 0 && ` • ${selectedSites.length} selected`}
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
            <Input
              placeholder="Search websites..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-full sm:w-64"
            />
          </div>
          
          {/* Filter */}
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-full sm:w-40">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="online">Online</SelectItem>
              <SelectItem value="offline">Offline</SelectItem>
              <SelectItem value="warning">Warning</SelectItem>
            </SelectContent>
          </Select>
          
          {/* Bulk Actions */}
          {selectedSites.length > 0 && (
            <Button
              variant="outline"
              onClick={handleBulkDelete}
              disabled={deleteWebsiteMutation.isPending}
              className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Remove ({selectedSites.length})
            </Button>
          )}
          
          <Button
            variant="outline"
            onClick={handleExport}
            className="flex-shrink-0"
          >
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Bulk Selection Header */}
      {websites.length > 0 && (
        <div className="mb-4 flex items-center space-x-4 p-3 bg-slate-50/50 dark:bg-slate-800/30 rounded-lg border border-slate-200/60 dark:border-slate-700/60">
          <Checkbox
            checked={selectedSites.length === filteredWebsites.length && filteredWebsites.length > 0}
            onCheckedChange={handleSelectAll}
          />
          <span className="text-sm text-slate-600 dark:text-slate-400">
            {selectedSites.length === filteredWebsites.length && filteredWebsites.length > 0
              ? `All ${filteredWebsites.length} websites selected`
              : `Select all ${filteredWebsites.length} websites`}
          </span>
          {selectedSites.length > 0 && (
            <Badge variant="secondary" className="ml-auto">
              {selectedSites.length} selected
            </Badge>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredWebsites.map((website) => {
          const statusColor = getStatusColor(website.status);
          const isSelected = selectedSites.includes(website.id);
          return (
            <Card
              key={website.id}
              className={`glass-effect p-4 border transition-all duration-300 group relative ${
                isSelected
                  ? "border-blue-300 dark:border-blue-600 bg-blue-50/30 dark:bg-blue-900/10 shadow-md"
                  : "border-slate-200/60 dark:border-slate-700/60 hover:border-slate-300 dark:hover:border-slate-600"
              }`}
            >
              {/* Selection checkbox */}
              <div className="absolute top-3 left-3 z-10">
                <Checkbox
                  checked={isSelected}
                  onCheckedChange={(checked) => handleSelectSite(website.id, !!checked)}
                  className="bg-white/90 dark:bg-slate-800/90 shadow-sm"
                />
              </div>
              
              {/* Actions dropdown */}
              <div className="absolute top-3 right-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="p-1 h-8 w-8 bg-white/90 dark:bg-slate-800/90 shadow-sm">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleOpenWebsite(website.url)}>
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Open Website
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-slate-600 dark:text-slate-400">
                      <Edit className="w-4 h-4 mr-2" />
                      Edit Settings
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-slate-600 dark:text-slate-400">
                      <Activity className="w-4 h-4 mr-2" />
                      View Logs
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      className="text-red-600 dark:text-red-400"
                      onClick={() => deleteWebsiteMutation.mutate(website.id)}
                      disabled={deleteWebsiteMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Remove
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              
              <div className="mt-6">
                <div className="flex items-center justify-between mb-3">
                  <div
                    className={`w-8 h-8 bg-${statusColor}-100 dark:bg-${statusColor}-900/30 rounded-lg flex items-center justify-center`}
                  >
                    {getStatusIcon(website.status)}
                  </div>
                  <div className="flex items-center space-x-2">
                    <div
                      className={`w-2 h-2 bg-${statusColor}-500 rounded-full ${
                        website.status === "offline" ? "animate-ping" : "animate-pulse-slow"
                      }`}
                    ></div>
                    <Badge 
                      variant={getStatusBadgeVariant(website.status)}
                      className={`text-xs ${
                        website.status === "online" 
                          ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
                          : website.status === "warning"
                          ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"
                          : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                      }`}
                    >
                      {website.status}
                    </Badge>
                  </div>
                </div>
                <h4 className="font-semibold text-slate-800 dark:text-slate-200 mb-1 truncate" title={website.name}>
                  {website.name}
                </h4>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-3 truncate" title={website.url}>
                  {website.url}
                </p>
                {/* Core Web Vitals Grid */}
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3 text-center">
                    <div>
                      <div className={`text-sm font-bold ${
                        website.responseTime && website.responseTime < 1000
                          ? "text-emerald-500"
                          : website.responseTime && website.responseTime < 2000
                          ? "text-amber-500"
                          : "text-red-500"
                      }`}>
                        {website.responseTime ? `${website.responseTime}ms` : "N/A"}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">Response</div>
                    </div>
                    <div>
                      <div className="text-sm font-bold text-slate-800 dark:text-slate-200">
                        {website.uptime}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">Uptime</div>
                    </div>
                  </div>
                  
                  {/* Core Web Vitals */}
                  <div className="grid grid-cols-3 gap-2 text-center pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                    <div>
                      <div className={`text-xs font-bold ${
                        (website.lcp || 0) < 2500 ? "text-emerald-500" :
                        (website.lcp || 0) < 4000 ? "text-amber-500" : "text-red-500"
                      }`}>
                        {website.lcp ? `${(website.lcp / 1000).toFixed(1)}s` : "N/A"}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">LCP</div>
                    </div>
                    <div>
                      <div className={`text-xs font-bold ${
                        (website.fid || 0) < 100 ? "text-emerald-500" :
                        (website.fid || 0) < 300 ? "text-amber-500" : "text-red-500"
                      }`}>
                        {website.fid ? `${website.fid}ms` : "N/A"}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">FID</div>
                    </div>
                    <div>
                      <div className={`text-xs font-bold ${
                        parseFloat(website.cls || "0") < 0.1 ? "text-emerald-500" :
                        parseFloat(website.cls || "0") < 0.25 ? "text-amber-500" : "text-red-500"
                      }`}>
                        {website.cls || "0.000"}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">CLS</div>
                    </div>
                  </div>
                </div>
                
                {/* Last Checked */}
                <div className="mt-3 pt-3 border-t border-slate-200/60 dark:border-slate-700/60">
                  <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
                    <span>Last checked:</span>
                    <span>{website.lastChecked ? new Date(website.lastChecked).toLocaleTimeString() : 'Never'}</span>
                  </div>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {filteredWebsites.length === 0 && (
        <div className="text-center py-16">
          <div className="w-24 h-24 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6">
            <Globe className="w-12 h-12 text-slate-400 dark:text-slate-500" />
          </div>
          <div className="text-slate-400 dark:text-slate-500 text-xl font-medium mb-2">
            {websites.length === 0 ? "No websites yet" : "No matches found"}
          </div>
          <p className="text-slate-500 dark:text-slate-400 mb-6 max-w-md mx-auto">
            {websites.length === 0
              ? "Start monitoring your first website and track its performance in real-time"
              : searchQuery
              ? `No websites match "${searchQuery}" with ${filter} status`
              : `No websites with ${filter} status`}
          </p>
          {websites.length === 0 && (
            <Button 
              className="bg-blue-500 hover:bg-blue-600 text-white"
              onClick={() => {
                // Trigger add website modal
                const event = new CustomEvent('open-add-website');
                window.dispatchEvent(event);
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Your First Website
            </Button>
          )}
        </div>
      )}
    </div>
  );
}