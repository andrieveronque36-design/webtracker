import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  BarChart3, 
  PieChart, 
  Activity, 
  Clock, 
  Zap, 
  AlertTriangle,
  ArrowUp,
  ArrowDown 
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import type { Website, DashboardStats } from "@shared/schema";

interface AnalyticsChartsProps {
  showDetailedView?: boolean;
}

export function AnalyticsCharts({ showDetailedView = false }: AnalyticsChartsProps = {}) {
  const [timeRange, setTimeRange] = useState("24h");

  const { data: websites = [] } = useQuery<Website[]>({
    queryKey: ["/api/websites"],
  });

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const analyticsData = useMemo(() => {
    const totalSites = websites.length;
    const avgResponseTime = websites
      .filter(w => w.responseTime)
      .reduce((sum, w) => sum + (w.responseTime || 0), 0) / Math.max(1, websites.filter(w => w.responseTime).length);
    
    const responseTimes = websites.map(w => ({
      name: w.name,
      value: w.responseTime || 0,
      status: w.status
    })).filter(item => item.value > 0).sort((a, b) => b.value - a.value);

    const statusDistribution = {
      online: websites.filter(w => w.status === 'online').length,
      warning: websites.filter(w => w.status === 'warning').length,
      offline: websites.filter(w => w.status === 'offline').length
    };

    return {
      totalSites,
      avgResponseTime: Math.round(avgResponseTime),
      responseTimes: responseTimes.slice(0, 10),
      statusDistribution
    };
  }, [websites]);

  return (
    <div className="space-y-6">
      {/* Core Web Vitals Analytics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="glass-effect p-4 border border-slate-200/60 dark:border-slate-700/60">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <p className="text-sm text-slate-600 dark:text-slate-400">Avg LCP</p>
              <div className="flex items-center space-x-1">
                <p className={`text-lg font-bold ${
                  (stats?.avgLCP || 0) < 2500 ? "text-emerald-500" :
                  (stats?.avgLCP || 0) < 4000 ? "text-amber-500" : "text-red-500"
                }`}>
                  {stats?.avgLCP ? `${(stats.avgLCP / 1000).toFixed(1)}s` : "N/A"}
                </p>
                {(stats?.avgLCP || 0) < 2500 && (
                  <ArrowDown className="w-4 h-4 text-emerald-500" />
                )}
              </div>
            </div>
          </div>
        </Card>
        
        <Card className="glass-effect p-4 border border-slate-200/60 dark:border-slate-700/60">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg flex items-center justify-center">
              <Activity className="w-5 h-5 text-emerald-500" />
            </div>
            <div>
              <p className="text-sm text-slate-600 dark:text-slate-400">Performance Score</p>
              <div className="flex items-center space-x-1">
                <p className={`text-lg font-bold ${
                  (stats?.performanceScore || 0) >= 90 ? "text-emerald-500" :
                  (stats?.performanceScore || 0) >= 70 ? "text-amber-500" : "text-red-500"
                }`}>
                  {stats?.performanceScore || 0}/100
                </p>
                {(stats?.performanceScore || 0) >= 90 && (
                  <ArrowUp className="w-4 h-4 text-emerald-500" />
                )}
              </div>
            </div>
          </div>
        </Card>
        
        <Card className="glass-effect p-4 border border-slate-200/60 dark:border-slate-700/60">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-purple-500" />
            </div>
            <div>
              <p className="text-sm text-slate-600 dark:text-slate-400">Fast Sites</p>
              <p className="text-lg font-bold text-slate-800 dark:text-slate-200">
                {websites.filter(w => w.responseTime && w.responseTime < 500).length}
              </p>
            </div>
          </div>
        </Card>
        
        <Card className="glass-effect p-4 border border-slate-200/60 dark:border-slate-700/60">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <p className="text-sm text-slate-600 dark:text-slate-400">Issues</p>
              <p className="text-lg font-bold text-slate-800 dark:text-slate-200">
                {(stats?.offlineSites || 0) + (stats?.warningSites || 0)}
              </p>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Response Time Ranking */}
        <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60 lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-blue-500" />
              <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">
                Response Time Analysis
              </h3>
            </div>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-28">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1h">Last hour</SelectItem>
                <SelectItem value="24h">Last 24h</SelectItem>
                <SelectItem value="7d">Last 7d</SelectItem>
                <SelectItem value="30d">Last 30d</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {analyticsData.responseTimes.length > 0 ? (
            <div className="space-y-3">
              {analyticsData.responseTimes.map((item, index) => {
                const maxValue = Math.max(...analyticsData.responseTimes.map(rt => rt.value));
                const percentage = maxValue > 0 ? (item.value / maxValue) * 100 : 0;
                
                return (
                  <div key={item.name} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                          #{index + 1} {item.name}
                        </span>
                        <Badge
                          variant={item.status === 'online' ? 'default' : item.status === 'warning' ? 'secondary' : 'destructive'}
                          className="text-xs"
                        >
                          {item.status}
                        </Badge>
                      </div>
                      <span className={`text-sm font-bold ${
                        item.value < 500 ? 'text-emerald-500' :
                        item.value < 1000 ? 'text-amber-500' :
                        'text-red-500'
                      }`}>
                        {item.value}ms
                      </span>
                    </div>
                    <Progress 
                      value={percentage} 
                      className="h-2" 
                    />
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="h-48 flex items-center justify-center text-center">
              <div>
                <BarChart3 className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                <p className="text-slate-600 dark:text-slate-400">No response time data available</p>
                <p className="text-sm text-slate-500 dark:text-slate-500">
                  Add websites to see response time analysis
                </p>
              </div>
            </div>
          )}
        </Card>

        {/* Status Distribution */}
        <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-2">
              <PieChart className="w-5 h-5 text-purple-500" />
              <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">
                Status Overview
              </h3>
            </div>
          </div>
          
          {websites.length > 0 ? (
            <div className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
                    <span className="text-sm text-slate-600 dark:text-slate-400">Online</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-lg font-bold text-emerald-500">{analyticsData.statusDistribution.online}</span>
                    <span className="text-xs text-slate-500">sites</span>
                  </div>
                </div>
                <Progress value={(analyticsData.statusDistribution.online / websites.length) * 100} className="h-2" />
              </div>
              
              {analyticsData.statusDistribution.warning > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
                      <span className="text-sm text-slate-600 dark:text-slate-400">Warning</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-lg font-bold text-amber-500">{analyticsData.statusDistribution.warning}</span>
                      <span className="text-xs text-slate-500">sites</span>
                    </div>
                  </div>
                  <Progress value={(analyticsData.statusDistribution.warning / websites.length) * 100} className="h-2" />
                </div>
              )}
              
              {analyticsData.statusDistribution.offline > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <span className="text-sm text-slate-600 dark:text-slate-400">Offline</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-lg font-bold text-red-500">{analyticsData.statusDistribution.offline}</span>
                      <span className="text-xs text-slate-500">sites</span>
                    </div>
                  </div>
                  <Progress value={(analyticsData.statusDistribution.offline / websites.length) * 100} className="h-2" />
                </div>
              )}

              <div className="mt-6 p-3 bg-slate-50/50 dark:bg-slate-800/30 rounded-lg">
                <div className="text-center">
                  <div className="text-2xl font-bold text-slate-800 dark:text-slate-200">
                    {Math.round((analyticsData.statusDistribution.online / websites.length) * 100)}%
                  </div>
                  <div className="text-sm text-slate-600 dark:text-slate-400">Overall Health</div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <PieChart className="w-12 h-12 text-slate-400 mx-auto mb-3" />
              <p className="text-slate-500 dark:text-slate-400">No status data available</p>
              <p className="text-sm text-slate-500 dark:text-slate-500">
                Add websites to see status distribution
              </p>
            </div>
          )}
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-slate-500" />
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">
              Recent Activity
            </h3>
          </div>
          <Button variant="outline" size="sm">
            View All Logs
          </Button>
        </div>
        
        <div className="space-y-3">
          {websites.length > 0 ? (
            websites.slice(0, 5).map((website) => (
              <div key={website.id} className="flex items-center justify-between p-3 bg-slate-50/50 dark:bg-slate-800/30 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${
                    website.status === 'online' ? 'bg-emerald-500' :
                    website.status === 'warning' ? 'bg-amber-500' :
                    'bg-red-500'
                  }`}></div>
                  <div>
                    <div className="font-medium text-slate-800 dark:text-slate-200">{website.name}</div>
                    <div className="text-sm text-slate-500 dark:text-slate-400">
                      {website.status === 'online' ? 'Health check passed' :
                       website.status === 'warning' ? 'Slow response detected' :
                       'Connection failed'}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-slate-500 dark:text-slate-400">
                    {website.lastChecked ? new Date(website.lastChecked).toLocaleTimeString() : 'Never'}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-slate-500 dark:text-slate-400">
              No recent activity to display
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}