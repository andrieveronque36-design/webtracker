import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertWebsiteSchema } from "@shared/schema";
import type { InsertWebsite } from "@shared/schema";

interface AddWebsiteModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddWebsiteModal({ open, onOpenChange }: AddWebsiteModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertWebsite>({
    resolver: zodResolver(insertWebsiteSchema),
    defaultValues: {
      name: "",
      url: "",
      status: "online",
      responseTime: undefined,
      uptime: "100%",
      isActive: true,
    },
  });

  const createWebsiteMutation = useMutation({
    mutationFn: async (data: InsertWebsite) => {
      const response = await apiRequest("POST", "/api/websites", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/websites"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Website added successfully",
      });
      form.reset();
      onOpenChange(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add website",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertWebsite) => {
    // Ensure URL has protocol
    if (!data.url.startsWith("http://") && !data.url.startsWith("https://")) {
      data.url = "https://" + data.url;
    }
    createWebsiteMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] glass-effect">
        <DialogHeader>
          <DialogTitle className="text-slate-800 dark:text-slate-200">
            Add New Website
          </DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-700 dark:text-slate-300">
                    Website Name
                  </FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g., My Website"
                      {...field}
                      className="bg-white/50 dark:bg-slate-800/50"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="url"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-700 dark:text-slate-300">
                    Website URL
                  </FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g., https://example.com"
                      {...field}
                      className="bg-white/50 dark:bg-slate-800/50"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createWebsiteMutation.isPending}
                className="flex-1 bg-blue-500 hover:bg-blue-600"
              >
                {createWebsiteMutation.isPending ? "Adding..." : "Add Website"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
