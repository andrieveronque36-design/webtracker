import { Card } from "@/components/ui/card";
import { Plus, Zap, Globe, TrendingUp, Shield, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import type { DashboardStats, Alert } from "@shared/schema";

interface StatusCardsProps {
  onAddWebsite: () => void;
}

export function StatusCards({ onAddWebsite }: StatusCardsProps) {
  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: unreadAlerts = [] } = useQuery<Alert[]>({
    queryKey: ["/api/alerts/unread"],
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
      {/* System Status Card */}
      <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60 hover:border-slate-300 dark:hover:border-slate-600 transition-all duration-300">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-emerald-500" />
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">
              System Health
            </h3>
          </div>
          <div className="w-3 h-3 bg-emerald-500 rounded-full animate-ping-slow"></div>
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-slate-600 dark:text-slate-400">Status</span>
            <span className="px-2 py-1 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 text-xs font-medium rounded-full">
              {stats?.totalSites === 0 ? "Ready" : "Active"}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-600 dark:text-slate-400">Uptime</span>
            <span className="font-bold text-slate-800 dark:text-slate-200">
              {stats?.overallUptime || "100%"}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-600 dark:text-slate-400">Avg Response</span>
            <span className="font-bold text-slate-800 dark:text-slate-200">
              {stats?.avgResponseTime || 0}ms
            </span>
          </div>
        </div>
      </Card>

      {/* Core Web Vitals Performance Card */}
      <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60 hover:border-slate-300 dark:hover:border-slate-600 transition-all duration-300">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Zap className="w-5 h-5 text-blue-500" />
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">
              Web Vitals
            </h3>
          </div>
          <div className={`px-2 py-1 text-xs font-medium rounded-full ${
            (stats?.performanceScore || 0) >= 90 
              ? "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400"
              : (stats?.performanceScore || 0) >= 70
              ? "bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400"
              : "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400"
          }`}>
            {stats?.performanceScore || 0}/100
          </div>
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-slate-600 dark:text-slate-400">LCP</span>
            <span className={`font-bold ${
              (stats?.avgLCP || 0) < 2500 ? "text-emerald-500" :
              (stats?.avgLCP || 0) < 4000 ? "text-amber-500" : "text-red-500"
            }`}>
              {stats?.avgLCP ? `${(stats.avgLCP / 1000).toFixed(1)}s` : "N/A"}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-600 dark:text-slate-400">FID</span>
            <span className={`font-bold ${
              (stats?.avgFID || 0) < 100 ? "text-emerald-500" :
              (stats?.avgFID || 0) < 300 ? "text-amber-500" : "text-red-500"
            }`}>
              {stats?.avgFID || 0}ms
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-600 dark:text-slate-400">CLS</span>
            <span className={`font-bold ${
              (stats?.avgCLS || 0) < 0.1 ? "text-emerald-500" :
              (stats?.avgCLS || 0) < 0.25 ? "text-amber-500" : "text-red-500"
            }`}>
              {stats?.avgCLS?.toFixed(3) || "0.000"}
            </span>
          </div>
        </div>
      </Card>

      {/* Monitoring Stats Card */}
      <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60 hover:border-slate-300 dark:hover:border-slate-600 transition-all duration-300">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Globe className="w-5 h-5 text-purple-500" />
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">
              Monitoring
            </h3>
          </div>
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-slate-600 dark:text-slate-400">Total Sites</span>
            <span className="font-bold text-purple-500">
              {stats?.totalSites || 0}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-600 dark:text-slate-400">Online</span>
            <span className="font-bold text-emerald-500">
              {stats?.onlineSites || 0}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-600 dark:text-slate-400">Issues</span>
            <span className="font-bold text-red-500">
              {(stats?.offlineSites || 0) + (stats?.warningSites || 0)}
            </span>
          </div>
        </div>
      </Card>

      {/* Active Alerts & Quick Actions Card */}
      <Card className="glass-effect p-6 border border-slate-200/60 dark:border-slate-700/60 hover:border-slate-300 dark:hover:border-slate-600 transition-all duration-300">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-amber-500" />
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">
              Quick Actions
            </h3>
          </div>
          {unreadAlerts.length > 0 && (
            <span className="px-2 py-1 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 text-xs font-bold rounded-full">
              {unreadAlerts.length}
            </span>
          )}
        </div>
        <div className="space-y-3">
          {stats?.totalSites === 0 ? (
            <>
              <Button
                onClick={onAddWebsite}
                className="w-full justify-start text-sm bg-blue-500/10 text-blue-600 hover:bg-blue-500/20 border-0"
                variant="outline"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Website
              </Button>
              <div className="text-xs text-slate-500 dark:text-slate-400 text-center mt-2">
                Start monitoring websites in seconds
              </div>
            </>
          ) : (
            unreadAlerts.length === 0 ? (
              <>
                <Button
                  onClick={onAddWebsite}
                  className="w-full justify-start text-sm bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 border-0"
                  variant="outline"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Website
                </Button>
                <div className="text-xs text-emerald-600 dark:text-emerald-400 text-center mt-2">
                  All systems operational ✓
                </div>
              </>
            ) : (
              unreadAlerts.slice(0, 2).map((alert) => (
                <div key={alert.id} className="flex items-center space-x-3 p-2 rounded-lg bg-red-50/50 dark:bg-red-900/10">
                  <div
                    className={`w-2 h-2 rounded-full animate-pulse ${
                      alert.type === "error"
                        ? "bg-red-500"
                        : alert.type === "warning"
                        ? "bg-amber-500"
                        : "bg-blue-500"
                    }`}
                  ></div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-slate-800 dark:text-slate-200">
                      {alert.title}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {new Date(alert.createdAt!).toLocaleString()}
                    </div>
                  </div>
                </div>
              ))
            )
          )}
        </div>
      </Card>

    </div>
  );
}
