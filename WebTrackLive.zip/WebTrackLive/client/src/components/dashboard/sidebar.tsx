import { Link, useLocation } from "wouter";
import { useTheme } from "@/components/theme-provider";
import { TrendingUp, Globe, Bell, BarChart3, Settings, Sun, Moon } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Alert } from "@shared/schema";

export function Sidebar() {
  const [location] = useLocation();
  const { theme, toggleTheme } = useTheme();

  const { data: unreadAlerts = [] } = useQuery<Alert[]>({
    queryKey: ["/api/alerts/unread"],
  });

  const menuItems = [
    { path: "/", label: "Dashboard", icon: TrendingUp },
    { path: "/websites", label: "Websites", icon: Globe },
    { path: "/alerts", label: "Alerts", icon: Bell, badge: unreadAlerts.length },
    { path: "/analytics", label: "Analytics", icon: BarChart3 },
    { path: "/settings", label: "Settings", icon: Settings },
  ];

  return (
    <aside className="w-64 glass-effect border-r border-slate-200 dark:border-slate-700 transition-all duration-300">
      <div className="flex flex-col h-full">
        {/* Logo & Brand */}
        <div className="flex items-center px-6 py-4 border-b border-slate-200 dark:border-slate-700">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <TrendingUp className="text-white text-sm" />
          </div>
          <span className="ml-3 text-xl font-bold text-slate-800 dark:text-slate-200">
            WebTracker
          </span>
        </div>

        {/* Navigation Menu */}
        <nav className="flex-1 px-4 py-6 space-y-2">
          {menuItems.map(({ path, label, icon: Icon, badge }) => {
            const isActive = location === path || (path !== "/" && location.startsWith(path));
            return (
              <Link
                key={path}
                href={path}
                className={`flex items-center px-3 py-3 rounded-lg transition-all duration-200 ${
                  isActive
                    ? "bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20"
                    : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="ml-3 font-medium">{label}</span>
                {badge !== undefined && badge > 0 && (
                  <span className="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                    {badge}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>

        {/* User Profile & Theme Toggle */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <img
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=40&h=40"
                alt="User profile"
                className="w-8 h-8 rounded-full"
              />
              <div className="ml-2">
                <div className="text-sm font-medium text-slate-800 dark:text-slate-200">
                  John Doe
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">Admin</div>
              </div>
            </div>
            {/* Theme Toggle Button */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-all duration-200"
            >
              {theme === "dark" ? (
                <Sun className="w-4 h-4 text-slate-600 dark:text-slate-400" />
              ) : (
                <Moon className="w-4 h-4 text-slate-600 dark:text-slate-400" />
              )}
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}
