import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWebsiteSchema, insertAlertSchema } from "@shared/schema";

// Core Web Vitals monitoring simulation
async function startCoreWebVitalsMonitoring() {
  const monitorInterval = 30000; // Monitor every 30 seconds

  setInterval(async () => {
    try {
      const websites = await storage.getWebsites();
      
      for (const website of websites) {
        if (!website.isActive) continue;

        // Simulate Core Web Vitals collection with realistic values
        const vitals = generateRealisticVitals(website.url);
        
        await storage.updateWebsite(website.id, {
          ...vitals,
          lastChecked: new Date(),
          responseTime: vitals.responseTime,
        });

        // Create alerts for poor performance
        if (vitals.lcp && vitals.lcp > 4000) {
          await storage.createAlert({
            websiteId: website.id,
            title: `Poor LCP Performance: ${website.name}`,
            message: `Largest Contentful Paint is ${vitals.lcp}ms (> 4s). Consider optimizing images and server response time.`,
            type: "warning",
            isRead: false,
          });
        }

        if (vitals.cls && parseFloat(vitals.cls) > 0.25) {
          await storage.createAlert({
            websiteId: website.id,
            title: `High Layout Shift: ${website.name}`,
            message: `Cumulative Layout Shift is ${vitals.cls} (> 0.25). Check for images without dimensions and dynamic content.`,
            type: "warning",
            isRead: false,
          });
        }
      }
    } catch (error) {
      console.error("Core Web Vitals monitoring error:", error);
    }
  }, monitorInterval);
}

function generateRealisticVitals(url: string) {
  // Generate realistic Core Web Vitals based on URL characteristics
  const isLocal = url.includes('localhost') || url.includes('127.0.0.1');
  const domain = url.replace(/(http|https):\/\//, '').split('/')[0];
  
  // Use URL hash for consistent but varied values
  const urlHash = hashCode(domain);
  const variance = (urlHash % 100) / 100; // 0-1 variance based on URL
  
  return {
    // LCP: Good < 2.5s, Needs improvement 2.5-4s, Poor > 4s
    lcp: Math.round(1000 + (isLocal ? 500 : 2000) * variance + Math.random() * 1000),
    
    // FID: Good < 100ms, Needs improvement 100-300ms, Poor > 300ms  
    fid: Math.round(20 + (isLocal ? 30 : 150) * variance + Math.random() * 50),
    
    // CLS: Good < 0.1, Needs improvement 0.1-0.25, Poor > 0.25
    cls: (0.05 + (isLocal ? 0.02 : 0.15) * variance + Math.random() * 0.05).toFixed(3),
    
    // FCP: Good < 1.8s, Needs improvement 1.8-3s, Poor > 3s
    fcp: Math.round(800 + (isLocal ? 300 : 1200) * variance + Math.random() * 500),
    
    // TTI: Good < 3.8s, Needs improvement 3.8-7.3s, Poor > 7.3s  
    tti: Math.round(2000 + (isLocal ? 1000 : 3000) * variance + Math.random() * 1500),
    
    // TBT: Good < 200ms, Needs improvement 200-600ms, Poor > 600ms
    tbt: Math.round(50 + (isLocal ? 50 : 300) * variance + Math.random() * 200),
    
    // Basic response time
    responseTime: Math.round(100 + (isLocal ? 50 : 400) * variance + Math.random() * 200),
  };
}

function hashCode(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  return Math.abs(hash);
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Website routes
  app.get("/api/websites", async (req, res) => {
    try {
      const websites = await storage.getWebsites();
      res.json(websites);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch websites" });
    }
  });

  app.get("/api/websites/:id", async (req, res) => {
    try {
      const website = await storage.getWebsite(req.params.id);
      if (!website) {
        return res.status(404).json({ message: "Website not found" });
      }
      res.json(website);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch website" });
    }
  });

  app.post("/api/websites", async (req, res) => {
    try {
      const validatedData = insertWebsiteSchema.parse(req.body);
      const website = await storage.createWebsite(validatedData);
      res.status(201).json(website);
    } catch (error) {
      res.status(400).json({ message: "Invalid website data" });
    }
  });

  app.patch("/api/websites/:id", async (req, res) => {
    try {
      const website = await storage.updateWebsite(req.params.id, req.body);
      if (!website) {
        return res.status(404).json({ message: "Website not found" });
      }
      res.json(website);
    } catch (error) {
      res.status(500).json({ message: "Failed to update website" });
    }
  });

  app.delete("/api/websites/:id", async (req, res) => {
    try {
      const success = await storage.deleteWebsite(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Website not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete website" });
    }
  });

  // Alert routes
  app.get("/api/alerts", async (req, res) => {
    try {
      const alerts = await storage.getAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  app.get("/api/alerts/unread", async (req, res) => {
    try {
      const alerts = await storage.getUnreadAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch unread alerts" });
    }
  });

  app.post("/api/alerts", async (req, res) => {
    try {
      const validatedData = insertAlertSchema.parse(req.body);
      const alert = await storage.createAlert(validatedData);
      res.status(201).json(alert);
    } catch (error) {
      res.status(400).json({ message: "Invalid alert data" });
    }
  });

  app.patch("/api/alerts/:id/read", async (req, res) => {
    try {
      const success = await storage.markAlertAsRead(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Alert not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to mark alert as read" });
    }
  });

  // Core Web Vitals monitoring route
  app.post("/api/websites/:id/vitals", async (req, res) => {
    try {
      const { lcp, fid, cls, fcp, tti, tbt } = req.body;
      const website = await storage.updateWebsite(req.params.id, {
        lcp, fid, cls, fcp, tti, tbt,
        lastChecked: new Date()
      });
      if (!website) {
        return res.status(404).json({ message: "Website not found" });
      }
      res.json(website);
    } catch (error) {
      res.status(500).json({ message: "Failed to update Core Web Vitals" });
    }
  });

  // Start Core Web Vitals monitoring for all websites
  startCoreWebVitalsMonitoring();

  const httpServer = createServer(app);
  return httpServer;
}
