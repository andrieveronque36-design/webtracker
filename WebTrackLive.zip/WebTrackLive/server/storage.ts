import { type Website, type InsertWebsite, type Alert, type InsertAlert, type DashboardStats } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Website methods
  getWebsites(): Promise<Website[]>;
  getWebsite(id: string): Promise<Website | undefined>;
  createWebsite(website: InsertWebsite): Promise<Website>;
  updateWebsite(id: string, updates: Partial<Website>): Promise<Website | undefined>;
  deleteWebsite(id: string): Promise<boolean>;
  
  // Alert methods
  getAlerts(): Promise<Alert[]>;
  getUnreadAlerts(): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  markAlertAsRead(id: string): Promise<boolean>;
  
  // Dashboard stats
  getDashboardStats(): Promise<DashboardStats>;
}

export class MemStorage implements IStorage {
  private websites: Map<string, Website>;
  private alerts: Map<string, Alert>;

  constructor() {
    this.websites = new Map();
    this.alerts = new Map();
  }


  async getWebsites(): Promise<Website[]> {
    return Array.from(this.websites.values()).filter(w => w.isActive);
  }

  async getWebsite(id: string): Promise<Website | undefined> {
    return this.websites.get(id);
  }

  async createWebsite(insertWebsite: InsertWebsite): Promise<Website> {
    const id = randomUUID();
    const website: Website = {
      id,
      name: insertWebsite.name,
      url: insertWebsite.url,
      status: insertWebsite.status || "online",
      responseTime: insertWebsite.responseTime || null,
      uptime: insertWebsite.uptime || "100%",
      lastChecked: new Date(),
      isActive: insertWebsite.isActive !== undefined ? insertWebsite.isActive : true,
      // Core Web Vitals - initialize with null values
      lcp: insertWebsite.lcp || null,
      fid: insertWebsite.fid || null,
      cls: insertWebsite.cls || null,
      fcp: insertWebsite.fcp || null,
      tti: insertWebsite.tti || null,
      tbt: insertWebsite.tbt || null,
    };
    this.websites.set(id, website);
    return website;
  }

  async updateWebsite(id: string, updates: Partial<Website>): Promise<Website | undefined> {
    const website = this.websites.get(id);
    if (!website) return undefined;
    
    const updatedWebsite = { ...website, ...updates };
    this.websites.set(id, updatedWebsite);
    return updatedWebsite;
  }

  async deleteWebsite(id: string): Promise<boolean> {
    const website = this.websites.get(id);
    if (!website) return false;
    
    // Soft delete by setting isActive to false
    website.isActive = false;
    this.websites.set(id, website);
    return true;
  }

  async getAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getUnreadAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values())
      .filter(alert => !alert.isRead)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = randomUUID();
    const alert: Alert = {
      id,
      websiteId: insertAlert.websiteId || null,
      title: insertAlert.title,
      message: insertAlert.message || null,
      type: insertAlert.type,
      isRead: insertAlert.isRead !== undefined ? insertAlert.isRead : false,
      createdAt: new Date(),
    };
    this.alerts.set(id, alert);
    return alert;
  }

  async markAlertAsRead(id: string): Promise<boolean> {
    const alert = this.alerts.get(id);
    if (!alert) return false;
    
    alert.isRead = true;
    this.alerts.set(id, alert);
    return true;
  }

  async getDashboardStats(): Promise<DashboardStats> {
    const websites = await this.getWebsites();
    const totalSites = websites.length;
    const onlineSites = websites.filter(w => w.status === "online").length;
    const offlineSites = websites.filter(w => w.status === "offline").length;
    const warningSites = websites.filter(w => w.status === "warning").length;
    
    const responseTimes = websites
      .filter(w => w.responseTime !== null)
      .map(w => w.responseTime!);
    const avgResponseTime = responseTimes.length > 0 
      ? Math.round(responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length)
      : 0;

    const overallUptime = totalSites > 0 ? "100%" : "0%";

    // Calculate Core Web Vitals averages
    const lcpValues = websites.filter(w => w.lcp !== null).map(w => w.lcp!);
    const fidValues = websites.filter(w => w.fid !== null).map(w => w.fid!);
    const clsValues = websites.filter(w => w.cls !== null).map(w => parseFloat(w.cls!));
    const fcpValues = websites.filter(w => w.fcp !== null).map(w => w.fcp!);
    const ttiValues = websites.filter(w => w.tti !== null).map(w => w.tti!);
    const tbtValues = websites.filter(w => w.tbt !== null).map(w => w.tbt!);

    const avgLCP = lcpValues.length > 0 ? Math.round(lcpValues.reduce((a, b) => a + b, 0) / lcpValues.length) : 0;
    const avgFID = fidValues.length > 0 ? Math.round(fidValues.reduce((a, b) => a + b, 0) / fidValues.length) : 0;
    const avgCLS = clsValues.length > 0 ? Math.round((clsValues.reduce((a, b) => a + b, 0) / clsValues.length) * 1000) / 1000 : 0;
    const avgFCP = fcpValues.length > 0 ? Math.round(fcpValues.reduce((a, b) => a + b, 0) / fcpValues.length) : 0;
    const avgTTI = ttiValues.length > 0 ? Math.round(ttiValues.reduce((a, b) => a + b, 0) / ttiValues.length) : 0;
    const avgTBT = tbtValues.length > 0 ? Math.round(tbtValues.reduce((a, b) => a + b, 0) / tbtValues.length) : 0;

    // Calculate performance score based on Core Web Vitals (simplified scoring)
    let performanceScore = 100;
    if (avgLCP > 0) {
      if (avgLCP > 4000) performanceScore -= 20; // Poor LCP
      else if (avgLCP > 2500) performanceScore -= 10; // Needs improvement
    }
    if (avgFID > 0) {
      if (avgFID > 300) performanceScore -= 20; // Poor FID
      else if (avgFID > 100) performanceScore -= 10; // Needs improvement
    }
    if (avgCLS > 0) {
      if (avgCLS > 0.25) performanceScore -= 20; // Poor CLS
      else if (avgCLS > 0.1) performanceScore -= 10; // Needs improvement
    }
    performanceScore = Math.max(0, performanceScore);

    return {
      totalSites,
      onlineSites,
      offlineSites,
      warningSites,
      avgResponseTime,
      overallUptime,
      avgLCP,
      avgFID,
      avgCLS,
      avgFCP,
      avgTTI,
      avgTBT,
      performanceScore,
    };
  }
}

export const storage = new MemStorage();
